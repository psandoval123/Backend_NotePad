from sqlmodel import Session, select
from models.note import Note
from schemas.note_schema import NoteCreate, NoteResponse


class NoteService:

    @staticmethod
    def get_all(session: Session, user_id: int):
        notes = session.exec(
            select(Note).where(Note.owner_id == user_id)
        ).all()

        return [
            NoteResponse(
                id=n.id,
                title=n.title,
                content=n.content,          # markdown original
                created_at=n.created_at
            )
            for n in notes
        ]

    @staticmethod
    def create_note(session: Session, note_data: NoteCreate, user_id: int):
        note = Note(
            title=note_data.title,
            content=note_data.content,
            owner_id=user_id
        )
        session.add(note)
        session.commit()
        session.refresh(note)

        # Retornamos NoteResponse
        return NoteResponse(
            id=note.id,
            title=note.title,
            content=note.content,
            created_at=note.created_at
        )

    @staticmethod
    def update_note(session: Session, note_id: int, note_data: NoteCreate, user_id: int):
        note = session.get(Note, note_id)
        if not note or note.owner_id != user_id:
            return None

        note.title = note_data.title
        note.content = note_data.content

        session.commit()
        session.refresh(note)

        return NoteResponse(
            id=note.id,
            title=note.title,
            content=note.content,
            created_at=note.created_at
        )

    @staticmethod
    def delete_note(session: Session, note_id: int, user_id: int):
        note = session.get(Note, note_id)
        if not note or note.owner_id != user_id:
            return None

        session.delete(note)
        session.commit()
        return True
