from sqlmodel import Session, select
from models.user import User
from passlib.hash import bcrypt

class UserService:

    @staticmethod
    def create_user(session: Session, username: str, password: str):
        existing = session.exec(select(User).where(User.username == username)).first()
        if existing:
            raise ValueError("El usuario ya existe")

        user = User(username=username, password=bcrypt.hash(password))
        session.add(user)
        session.commit()
        session.refresh(user)
        return user

    @staticmethod
    def authenticate(session: Session, username: str, password: str):
        user = session.exec(select(User).where(User.username == username)).first()
        if not user or not bcrypt.verify(password, user.password):
            return None
        return user
