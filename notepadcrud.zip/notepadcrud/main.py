from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI
from contextlib import asynccontextmanager
from database import init_db
from controllers.user_controller import router as user_router
from controllers.note_controller import router as note_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield
    print("App finalizada")

app = FastAPI(lifespan=lifespan)

# Configuración de CORS
origins = [
    "http://localhost:5173",  # tu frontend
    "http://127.0.0.1:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(user_router)
app.include_router(note_router)
