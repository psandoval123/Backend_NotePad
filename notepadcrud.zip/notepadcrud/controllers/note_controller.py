from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from database import get_session
from schemas.note_schema import NoteCreate
from services.note_service import NoteService
from utils import get_current_user
from models.user import User

router = APIRouter(prefix="/notes")

@router.get("/")
def all_notes(
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    return NoteService.get_all(session, user.id)

@router.post("/")
def create(
    note: NoteCreate,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    return NoteService.create_note(session, note, user.id)

@router.put("/{note_id}")
def update(
    note_id: int,
    note: NoteCreate,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    updated = NoteService.update_note(session, note_id, note, user.id)
    if not updated:
        raise HTTPException(status_code=404, detail="Nota no encontrada xd")
    return updated

@router.delete("/{note_id}")
def delete(
    note_id: int,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session)
):
    deleted = NoteService.delete_note(session, note_id, user.id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Nota no encontrada")
    return {"message": "Eliminada"}
