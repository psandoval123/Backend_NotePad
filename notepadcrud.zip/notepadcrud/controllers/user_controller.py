from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlmodel import Session

from database import get_session
from services.user_service import UserService
from utils import create_token
from schemas.user_schema import UserCreate  # Asegúrate de tener este schema
from fastapi import status


router = APIRouter(prefix="/auth")

@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(data: UserCreate, session: Session = Depends(get_session)):
    try:
        UserService.create_user(session, data.username, data.password)
        return {"201": "Usuario creado"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/login")
def login(
    form: OAuth2PasswordRequestForm = Depends(),
    session: Session = Depends(get_session)
):
    user = UserService.authenticate(session, form.username, form.password)
    print(user)
    if not user:
        raise HTTPException(status_code=401, detail="Credenciales inválidas")

    token = create_token(user)

    return {
        "access_token": token,
        "token_type": "bearer"
    }

