from sqlmodel import SQLModel

class UserCreate(SQLModel):
    username: str
    password: str

    class Config:
        orm_mode = True

class UserResponse(SQLModel):
    id: int
    username: str
