from sqlmodel import SQLModel
from datetime import datetime


class NoteCreate(SQLModel):
    title: str
    content: str


class NoteResponse(SQLModel):
    id: int
    title: str
    content: str
    created_at: datetime