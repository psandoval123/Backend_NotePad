import os
from sqlmodel import SQLModel, create_engine, Session
from contextlib import contextmanager

# Ejemplo de formato:
# postgresql://usuario:password@host:port/nombre_db
# Es buena práctica configurar esto vía variable de entorno.
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:root@localhost:5432/notas_db"
)

# create_engine usa conexiones síncronas por defecto, que van bien con FastAPI + SQLModel
engine = create_engine(DATABASE_URL, echo=True, connect_args={})

def init_db() -> None:
    """
    Crea las tablas declaradas en los modelos (si no existen).
    Llama a esta función en el evento startup de FastAPI.
    """
    from models.user import User
    from models.note import Note
    SQLModel.metadata.create_all(engine)

# Dependency para endpoints: yield una sesión por petición
def get_session():
    """
    Dependency de FastAPI para obtener una sesión:
        from database import get_session
        session: Session = Depends(get_session)
    """
    with Session(engine) as session:
        yield session

# Opcional: helper para obtener una sesión en código fuera de FastAPI
@contextmanager
def session_scope():
    session = Session(engine)
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()
